package com.ts.esclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Hello world!
 *
 */
@SpringBootApplication
public class ESClientApp 
{

    public static void main( String[] args )
    {
        SpringApplication.run(ESClientApp.class, args); 
    }
}
