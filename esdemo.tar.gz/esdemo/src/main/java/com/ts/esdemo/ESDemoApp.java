package com.ts.esdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ESDemoApp {

	public static void main(String[] args) {
		SpringApplication.run(ESDemoApp.class, args);
	}
}
