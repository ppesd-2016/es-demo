package com.ts.esdemo.controller;

import org.elasticsearch.action.admin.cluster.health.ClusterHealthRequest;
import org.elasticsearch.action.admin.cluster.health.ClusterHealthResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ts.esdemo.search.client.ESDemoSearchClient;

@RestController
@RequestMapping("/es")
public class ESDemoController {

	@Autowired
	private ESDemoSearchClient client;

	@RequestMapping("/clusterhealth")
	public String getClusterHealth() {
		ClusterHealthResponse response = this.client.getClient().admin().cluster().health(new ClusterHealthRequest())
				.actionGet();
		return response.toString();
	}

}
